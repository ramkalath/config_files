// VERSION _must_ be \d.\d+
#define VERSION "9.22"
#define DATE	"2016-01-23"
