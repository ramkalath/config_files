#!/bin/bash

INSTALL_DIR=$PWD

./configure
make
sudo make install
pushd $HOME/
ln -s ${INSTALL_DIR}/.Xresources .
xrdb $HOME/.Xresources
