#!/bin/bash

# dependencies
# install xclip and libncurses5-dev for your computer

# for debian based systems
sudo apt install xclip libncurses5-dev
./configure
make
sudo make install
pushd $HOME/
sudo ln -s $HOME/Downloads/vim/.vimrc .
mkdir -p $HOME/.vim

