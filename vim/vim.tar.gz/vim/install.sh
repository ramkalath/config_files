#!/bin/bash

# dependencies
# install xclip for your computer

./configure
make
sudo make install
pushd $HOME/
sudo ln -s $HOME/Downloads/vim/.vimrc .
mkdir -p $HOME/.vim

