#!/bin/bash
~/config_files/st/st -e tmux
